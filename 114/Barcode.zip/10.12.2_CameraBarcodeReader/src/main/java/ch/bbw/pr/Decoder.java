package ch.bbw.pr;

/**
 * @author Janne Chartron
 * @version 04.04.2024
 */
public class Decoder {

   static public String decode(String barcode) {
      //implement decoding here.

      return barcode + "\n2nd" + "\n3rd";
   }
}
