# 10_CodeConverter

Vorbereitetes aber unvollständig implementiertes Projekt für das Thema Codes.

(c) 2024 Peter Rutschmann

