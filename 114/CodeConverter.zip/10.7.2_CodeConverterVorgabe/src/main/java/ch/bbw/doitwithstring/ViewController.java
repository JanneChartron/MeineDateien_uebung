package ch.bbw.doitwithstring;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * ViewController
 *    Kontrolliert Zusammenspiel mit der View.
 *    Regiert auf Aktionen in der View.
 * @author Peter Rutschmann
 * @version 06.12.2021
 */
@Controller
public class ViewController {

    ViewData viewData = new  ViewData();

    @GetMapping("/")
    public String redirect() {
        return "redirect:/convert";
    }

    @GetMapping("/convert")
    public String showView(Model model) {
        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe1"})
    public String aufgabe1(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe1: " + viewData);
        System.out.println("ViewController.aufgabe1: " + viewData.getFirstString());
        System.out.println("ViewController.aufgabe1: " + viewData.getSecondString());
        System.out.println("ViewController.aufgabe1: " + viewData.getThirdString());
        System.out.println("ViewController.aufgabe1: " + viewData.getOutput());

        // Aufgabe 1
        String input = viewData.getFirstString().toLowerCase().trim();
        StringBuilder result = new StringBuilder();

        String abc = "abcdefghijklmnopqrstuvwxyz";
        String[] morse = {".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--.."};

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c == ' ') {
                result.append(" ");
            } else {
                int index = abc.indexOf(c);
                if (index != -1) {
                    result.append(morse[index]).append(" ");
                }
            }
        }

        viewData.setOutput(result.toString());
        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }


    @PostMapping(value = "/convert", params = {"showButton=aufgabe2"})
    public String aufgabe2(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe2");

        // Aufgabe 2
        String input = viewData.getFirstString().trim();
        String[] morsezeichen = input.split("/");

        StringBuilder ergebnis = new StringBuilder();

        String numbers = ".-/-.../-.-./"; // Hier sollten Sie sicherstellen, dass dies die richtigen Morsezeichen sind
        String abc = "abcdefghijklmnopqrstuvwxyz";
        for (String morse : morsezeichen) {
            int index = numbers.indexOf(morse);
            if (index != -1) {
                char buchstabe = abc.charAt(index);
                ergebnis.append(buchstabe);
            }
        }

        viewData.setOutput(ergebnis.toString());
        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }


    @PostMapping(value = "/convert", params = {"showButton=aufgabe3"})
    public String aufgabe3(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe3");

        //Aufgabe 3
        //String ergebnis = <ergänzen>

        //Ergebnis an GUI Daten übergebend
        //viewData.setOutput(ergebnis);

        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe4"})
    public String aufgabe4(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe4");

        //Aufgabe 4

        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe5"})
    public String aufgabe5(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe5");

        //Aufgabe 5

        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe6"})
    public String aufgabe6(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe6");

        //Aufgabe 6

        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=aufgabe7"})
    public String aufgabe7(Model model, @ModelAttribute("viewData") ViewData viewData) {
        System.out.println("ViewController.aufgabe7");

        //Aufgabe 7

        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }

    @PostMapping(value = "/convert", params = {"showButton=resetView"})
    public String resetView(Model model) {
        viewData = new ViewData();
        model.addAttribute("viewData", viewData);
        return "CodeConvertForm";
    }
}
