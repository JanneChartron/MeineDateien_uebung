package ch.bbw.doitwithstring;

/**
 * ViewData
 *    Daten für die Anzeige in der View.
 * @author Peter Rutschmann
 * @version 07.09.2021
 */
public class ViewData {
   private String firstString = "";
   private String secondString = "";
   private String thirdString = "";
   private String output = "";

   public String getFirstString() {
      return firstString;
   }

   public void setFirstString(String firstString) {
      this.firstString = firstString;
   }

   public String getSecondString() {
      return secondString;
   }

   public void setSecondString(String secondString) {
      this.secondString = secondString;
   }

   public String getThirdString() {
      return thirdString;
   }

   public void setThirdString(String thirdString) {
      this.thirdString = thirdString;
   }

   public String getOutput() {
      return output;
   }

   public void setOutput(String output) {
      this.output = output;
   }

   @Override
   public String toString() {
      return "ViewData{" +
            "firstString='" + firstString + '\'' +
            ", secondString='" + secondString + '\'' +
            ", thirdString='" + thirdString + '\'' +
            ", output='" + output + '\'' +
            '}';
   }
}
