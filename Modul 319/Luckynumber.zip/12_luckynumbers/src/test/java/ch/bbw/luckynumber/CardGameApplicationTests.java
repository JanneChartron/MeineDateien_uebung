package ch.bbw.luckynumber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
