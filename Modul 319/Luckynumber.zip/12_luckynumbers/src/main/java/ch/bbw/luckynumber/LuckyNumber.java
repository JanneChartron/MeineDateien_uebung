package ch.bbw.luckynumber;

import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.Random;


/**
 * LuckyNumber
 * Fachklasse für das Berechnen von Glueckszahlen
 *
 * @author Peter Rutschmann
 * @date 06.09.2021
 */
public class LuckyNumber {

    public int singleDice(){
        int value = 0;
        Random zufall = new Random();
        value = zufall.nextInt(6)+1;
        return value;
    }

    public List<Integer> doubleDice(){
        List<Integer> list = new ArrayList<>();
        Random zufall = new Random();
        list.add(zufall.nextInt(6)+1);
        list.add(zufall.nextInt(6)+1);
        return list;
    }

    public boolean trueOrFalse(){
        boolean value;
        Random zufall = new Random();
        value = zufall.nextBoolean();
        return false;
    }

    public Set<Integer> sixLottoNumbers() {
        Set<Integer> set = new HashSet<Integer>();
        Random zufall = new Random();

        while (set.size() < 6) {
            int lottoNumber = zufall.nextInt(49) + 1;
            set.add(lottoNumber);
        }

        return set;
    }


    public String playingCard() {
        String[] cardSuits = {"Herz", "Kreuz", "Pik", "Karo"};
        String[] cardValues = {"Ass", "König", "Dame", "Bube", "10", "9", "8", "7", "6", "5", "4", "3", "2"};
        Random zufall = new Random();

        String randomSuit = cardSuits[zufall.nextInt(cardSuits.length)];
        String randomValue = cardValues[zufall.nextInt(cardValues.length)];

        return randomSuit + " " + randomValue;
    }


    public List<Integer> primeUpTo100() {
        List<Integer> list = new ArrayList<>();

        for (int number = 2; number <= 100; number++) {
            boolean isPrime = true;
            for (int divisor = 2; divisor < number; divisor++) {
                if (number % divisor == 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) {
                list.add(number);
            }
        }
        return list;
    }


    public int primeNextTo(int value) {
        if (value < 2) {
            return 2;
        }

        while (true) {
            value++;
            if (isPrime(value)) {
                return value;
            }
        }
    }

    private boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }

        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }

        return true;
    }

    public List<Integer> triangleNumbersUpTo(int value) {
        List<Integer> list = new ArrayList<Integer>();
        int n = 1;
        int triangle = 0;

        while (triangle <= value) {
            triangle += n;
            list.add(triangle);
            n++;
        }

        return list;
    }
}
