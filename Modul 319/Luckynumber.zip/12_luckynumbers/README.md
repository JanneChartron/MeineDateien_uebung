# 12_LuckyNumbers

Vorbereitetes aber unvollständig implementiertes Projekt für das Thema Klassen und Methoden.

(c) 2021 Peter Rutschmann

