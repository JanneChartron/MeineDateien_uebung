package ch.bbw.jc;

import ch.bbw.jc.Land;
// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Land land1 = new Land("Nord Amerika", 300000000, "Dritt groesstes Land","USA");
        Land land2 = new Land("",1300000000, "Siebt groesstes Land","Indien");
        land2.setKontinent("Asien");

        System.out.println("Erstes Land: ");
        System.out.println("Kontinent: " + land1.getKontinent());
        System.out.println("Einwohner: " + land1.getEinwohner());
        System.out.println("Groesse: " + land1.getGroesse());
        System.out.println("Name des Landes: " + land1.getNameland());

        System.out.println("Zeites Land: ");
        System.out.println("Kontinent: " + land2.getKontinent());
        System.out.println("Einwohner: " + land2.getEinwohner());
        System.out.println("Groesse: " + land2.getGroesse());
        System.out.println("Name des Landes: " + land2.getNameland());
    }
}