package ch.bbw.jc;

/**
 *
 * 5IA23b
 * Janne Chartron
 * Version 1
 *
 */

public class Land {
    public String Kontinent;
    public double Einwohner;
    public String Groesse;
    public String Nameland;


    public Land(String kontinent, double einwohner,String Groesse, String Nameland) {
        this.Kontinent = kontinent;
        this.Einwohner = einwohner;
        this.Groesse = Groesse;
        this.Nameland = Nameland;
    }

    public String getKontinent() {
        return Kontinent;
    }

    public void setKontinent(String kontinent) {
        Kontinent = kontinent;
    }

    public double getEinwohner() {
        return Einwohner;
    }

    public void setEinwohner(double einwohner) {
        Einwohner = einwohner;
    }

    public String getGroesse() {
        return Groesse;
    }

    public void setGroesse(String groesse) {
        Groesse = groesse;
    }

    public String getNameland() {
        return Nameland;
    }

    public void setNameland(String nameland) {
        Nameland = nameland;
    }

    @Override
    public String toString() {
        return "Land{" +
                "Kontinent='" + Kontinent + '\'' +
                ", Einwohner=" + Einwohner +
                ", Groesse='" + Groesse + '\'' +
                ", Nameland='" + Nameland + '\'' +
                '}';
    }
}
